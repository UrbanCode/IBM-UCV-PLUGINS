/*********************************************************************
* The index.js defines the configurable properties and interfaces of a
* plugin. The available plugin interface types are endpoints, sheduled events,
* and qualityHandlers (AKA parsers).
*
* The exported plugin interface objects contain an execute function. When
* Velocity executes those interfaces, it runs the execute function provided.
* For some examples check out the javascript files in the scheduledEvents,
* endpoints, and qualityHandlers folders.
***********************************************************************/
import sampleMetricsEndpoint from './endpoints/sampleMetricsEndpoint'
import secondSampleEndpoint from './endpoints/secondSampleEndpoint'
import sampleIssueUploadEvent from './scheduledEvents/sampleBuildsEvent'
import sampleBuildUploadEvent from './scheduledEvents/sampleIssuesEvent'
import sampleMetricsHandler from './qualityHandlers/sampleMetricsHandler'

/*
  Note that if you do not want to execute the sample interfaces, you can
  remove them from the exported endpoints, scheduledEvents, and qualityHandlers
  here.
*/
export default {
  properties: [
    {
      name: 'uploadSampleData',
      label: 'Upload Sample Data',
      type: 'Boolean',
      description: 'Checking this box will cause sample data to be uploaded into the UrbanCode Velocity server. The sample data can be used to gain understanding of the format of data and how it is used in UrbanCode Velocity when uploaded.',
      required: false
    },
    {
      name: 'ucvAccessKey',
      label: 'UrbanCode Velocity User Access Key',
      type: 'Secure',
      description: 'The user access key to authenticate with the UrbanCode Velocity server.',
      required: false
    },
    {
      name: 'sampleString',
      label: 'Sample String Property',
      type: 'String',
      description: 'String types expect text values as input (E.G. My String).',
      required: false
    },
    {
      name: 'sampleSecure',
      label: 'Sample Secure String Property',
      type: 'Secure',
      description: 'Secure types take normal text input but redact the value when displayed.',
      required: false
    },
    {
      name: 'sampleBoolean',
      label: 'Sample Boolean Property (True/False)',
      type: 'Boolean',
      description: 'Boolean types display a checkbox and be true when checked and false when unchecked.',
      required: false
    },
    {
      name: 'sampleArray',
      label: 'Sample Array Property',
      type: 'Array',
      description: 'Array types take a comma delimited list and convert them into an array value. (E.G. val1,val2,val3)',
      required: false
    },
    {
      name: 'sampleSelect',
      label: 'Sample Select Property (Radio Button)',
      type: 'Select',
      description: 'Select types display options in a radio button. The value will be the value field of the selected option. Use this instead of Dropdown when you want to display only a few options to choose from for better readability.',
      required: false,
      choices: [
        {
          label: 'Option 1',
          value: 'optionOne'
        },
        {
          label: 'Option 2',
          value: 'optionTwo'
        }
      ]
    },
    {
      name: 'sampleDropdown',
      label: 'Sample Dropdown Property',
      type: 'Dropdown',
      description: 'Dropdown types display a dropdown list of labels when clicked. The value will be the value field of the selected option. Use this instead of Select when you have an extensive list of options for better readability.',
      required: false,
      choices: [
        {
          label: 'Option 1',
          value: 'optionOne'
        },
        {
          label: 'Option 2',
          value: 'optionTwo'
        },
        {
          label: 'Option 3',
          value: 'optionThree'
        },
        {
          label: 'Option 4',
          value: 'optionFour'
        }
      ]
    }
  ],
  endpoints: [sampleMetricsEndpoint, secondSampleEndpoint],
  scheduledEvents: [sampleIssueUploadEvent, sampleBuildUploadEvent],
  taskDefinitions: [], // Currently not supported
  eventTriggers: [], // Currently not supported
  qualityHandlers: [sampleMetricsHandler],
  /*
    A pipelineDefinition can be used to configure your plugin in a pipeline.
    For more information view the 'Pipeline Definition' section of the README.
    The following provides an example:
    pipelineDefinition: {
      importsApplications: false,
      importsVersions: false,
      importsEnvironments: false
    },
  */
  displayName: 'Sample Template Plugin', // How the plugin shows in the UI
  pluginId: 'ucv-ext-sdk-template', // Must match the 'name' in package.json
  description: 'This is a template for basic npm plugin packages for UrbanCode Velocity.'
}
